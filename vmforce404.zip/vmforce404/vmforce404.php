<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Plugin\CMSPlugin;

class PlgSystemVmforce404 extends CMSPlugin
{
    protected $app;
    protected $db;

    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        $this->db = Factory::getDbo();
    }

    public function onAfterRoute()
    {
        if ($this->app->isClient('administrator')) {
            return;
        }

        $uri = Uri::getInstance();
        $fullPath = trim($uri->getPath(), '/');

        if (empty($fullPath) || strpos($fullPath, '.') !== false) {
            return;
        }

        if (strpos($fullPath, 'component/virtuemart/') === 0) {
            return;
        }

        if ($this->isExcludedPath($fullPath)) {
            return;
        }

        $parts = explode('/', $fullPath);
        
        if (count($parts) < 2) {
            return;
        }

        $isError = false;
        $currentParentId = 0;
        $currentPathAccumulator = ''; 

        foreach ($parts as $i => $slug) {
            if ($i > 0) {
                $currentPathAccumulator .= '/';
            }
            $currentPathAccumulator .= $slug;
            
            $foundCatId = null;

            $baseVariants = [$slug];
            $allVariants = $baseVariants;

            foreach ($allVariants as $v) {
                $cat = $this->queryCategoryExact($v, $currentParentId);
                if ($cat) {
                    $foundCatId = $cat['id'];
                    break;
                }
            }

            if ($foundCatId === null) {
                $menuData = $this->getMenuDataByPath($currentPathAccumulator);
                if ($menuData) {
                    $foundCatId = $menuData['catid'];
                }
            }

            if ($foundCatId !== null) {
                $currentParentId = $foundCatId;
            } else {
                if ($i === count($parts) - 1) {
                    $prodId = $this->queryProductExact($slug, $currentParentId, $allVariants);
                    if (!$prodId) {
                        $isError = true;
                    }
                } else {
                    $isError = true;
                }
                
                if ($isError) break;
            }
        }

        if ($isError) {
            http_response_code(404);
            header("HTTP/1.1 404 Not Found");
            
            $errorFile = null;
            
            $customPath = trim($this->params->get('custom_error_file', ''));
            if (!empty($customPath)) {
                if ($customPath[0] !== '/') {
                    $fullCustomPath = JPATH_SITE . '/' . ltrim($customPath, '/');
                } else {
                    $fullCustomPath = JPATH_SITE . $customPath;
                }
                
                if (file_exists($fullCustomPath)) {
                    $errorFile = $fullCustomPath;
                }
            }

            if (!$errorFile) {
                $template = $this->app->getTemplate();
                $templateFile = JPATH_SITE . '/templates/' . $template . '/error.php';
                
                if (file_exists($templateFile)) {
                    $errorFile = $templateFile;
                }
            }


            if ($errorFile) {
                include $errorFile;
            } else {
                echo "<h1>404 Not Found</h1><p>The requested page could not be found.</p>";
            }
            
            jexit();
        }
    }

    private function getMenuDataByPath($path) {
        $q = $this->db->getQuery(true)
            ->select('m.id, m.link, m.params')
            ->from('#__menu AS m')
            ->where('m.path = ' . $this->db->quote($path))
            ->where('m.client_id = 0')
            ->where('m.published = 1')
            ->where('m.language IN (' . $this->db->quote('*') . ',' . $this->db->quote(Factory::getLanguage()->getTag()) . ')');
        
        $this->db->setQuery($q);
        $item = $this->db->loadAssoc();

        if (!$item) return null;

        $catId = -1;
        if (strpos($item['link'], 'com_virtuemart') !== false && strpos($item['link'], 'view=category') !== false) {
            if (preg_match('/virtuemart_category_id=(\d+)/', $item['link'], $matches)) {
                $catId = (int)$matches[1];
            }
        }
        
        if ($catId == -1) {
            $params = json_decode($item['params'], true);
            if (isset($params['virtuemart_category_id'])) {
                $catId = (int)$params['virtuemart_category_id'];
            } else {
                $catId = 0;
            }
        }

        if ($catId > 0) {
            $checkQ = $this->db->getQuery(true)
                ->select('virtuemart_category_id')
                ->from('#__virtuemart_categories')
                ->where('virtuemart_category_id = ' . $catId)
                ->where('published = 1');
            $this->db->setQuery($checkQ);
            if (!$this->db->loadResult()) return null;
        }

        return ['id' => $item['id'], 'catid' => $catId];
    }

    private function queryCategoryExact($slug, $parentId) {
        $q = $this->db->getQuery(true)
            ->select('c.virtuemart_category_id AS id, cr.slug AS real_slug, cc.category_parent_id AS pid')
            ->from('#__virtuemart_categories AS c')
            ->join('INNER', '#__virtuemart_categories_ru_ru AS cr ON c.virtuemart_category_id = cr.virtuemart_category_id')
            ->join('LEFT', '#__virtuemart_category_categories AS cc ON c.virtuemart_category_id = cc.category_child_id')
            ->where('cr.slug = ' . $this->db->quote($slug))
            ->where('c.published = 1');
        
        if ($parentId === 0) {
            $q->where('(cc.category_parent_id = 0 OR cc.category_parent_id IS NULL)');
        } else {
            $q->where('cc.category_parent_id = ' . (int)$parentId);
        }
        
        $this->db->setQuery($q);
        $r = $this->db->loadAssoc();
        if ($r && $r['pid'] === null) $r['pid'] = 0;
        return $r;
    }

    private function queryProductExact($slug, $catId, $variants) {
        $toCheck = array_unique(array_merge([$slug], $variants));
        foreach ($toCheck as $s) {
            $q = $this->db->getQuery(true)
                ->select('p.virtuemart_product_id')
                ->from('#__virtuemart_products AS p')
                ->join('INNER', '#__virtuemart_product_categories AS pc ON p.virtuemart_product_id = pc.virtuemart_product_id')
                ->join('INNER', '#__virtuemart_products_ru_ru AS pr ON p.virtuemart_product_id = pr.virtuemart_product_id')
                ->where('pr.slug = ' . $this->db->quote($s))
                ->where('pc.virtuemart_category_id = ' . (int)$catId)
                ->where('p.published = 1');
            $this->db->setQuery($q);
            if ($res = $this->db->loadResult()) return $res;
        }
        return null;
    }

    private function isExcludedPath($path) {
        $ex = trim($this->params->get('excluded_paths', ''));
        if (empty($ex)) return false;
        $list = array_map('strtolower', array_filter(array_map('trim', explode("\n", $ex))));
        $p = strtolower($path);
        foreach ($list as $e) {
            if ($e && ($p === $e || strpos($p, $e . '/') === 0)) return true;
        }
        return false;
    }
}